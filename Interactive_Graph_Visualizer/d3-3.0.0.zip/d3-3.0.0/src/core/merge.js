d3.merge = function(arrays) {
  return Array.prototype.concat.apply([], arrays);
};
