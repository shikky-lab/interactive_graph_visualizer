require("./core/core");

require("util").puts(JSON.stringify({
  "name": "d3",
  "version": d3.version,
  "main": "./d3.js"
}, null, 2));
